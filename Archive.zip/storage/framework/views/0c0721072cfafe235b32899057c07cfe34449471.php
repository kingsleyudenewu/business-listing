<div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu" id="side-menu">
                <li>
                    <a href="<?php echo e(route('home')); ?>"
                       class="waves-effect">
                        <i class="ti-home"></i><span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('category.index')); ?>"
                       class="waves-effect">
                        <i class="ti-home"></i><span>Category</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>