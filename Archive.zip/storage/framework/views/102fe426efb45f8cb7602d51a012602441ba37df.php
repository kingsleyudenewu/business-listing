<?php $__env->startSection('content'); ?>

    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">

                    </div>
                    <?php if(auth()->user()->id): ?>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <button class="btn btn-primary waves-effect waves-light"
                                        data-toggle="modal" data-target="#accept">Add Business
                                    Listing
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="row">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/home.blade.php ENDPATH**/ ?>