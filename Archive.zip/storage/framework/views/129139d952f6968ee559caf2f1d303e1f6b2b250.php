<!doctype html>
<html lang="en">
<?php echo $__env->make('includes.head-meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<!-- Begin page -->
<div id="wrapper">
    <!-- Start Side bar -->
<?php if(!is_null(auth()->user())): ?>
    <?php echo $__env->make('includes.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<!--  End Sidebar -->

<?php if(!is_null(auth()->user())): ?>
    <!-- Start Content -->
        <div class="content-page">
            <?php echo $__env->yieldContent('content'); ?>
            <footer class="footer">&copy; <?php echo e(date('Y', time())); ?> <?php echo e(env('APP_NAME')); ?> <span
                    class="d-none
        d-sm-inline-block">-
                Crafted
                with <i class="mdi mdi-heart text-danger"></i> by Kingsley Udenewu</span>.
            </footer>
        </div>
        <!-- End Content-->
    <?php else: ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>


</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/layouts/app.blade.php ENDPATH**/ ?>