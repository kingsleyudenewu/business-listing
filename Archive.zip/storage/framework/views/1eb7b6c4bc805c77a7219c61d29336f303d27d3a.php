<?php $__env->startSection('content'); ?>

    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title"><?php echo e($pageTitle); ?></h4>
                    </div>
                    <?php if(auth()->user()->id): ?>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <button class="btn btn-primary waves-effect waves-light"
                                        data-toggle="modal" data-target="#accept">Add Category
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="row">
                <table id="datatable"
                       class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <?php if(auth()->user()->id): ?>
                            <th>Action</th>
                        <?php endif; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <?php if(auth()->user()->id): ?>
                                <td>
                                    <a href="#"
                                       class="btn btn-primary edit_category"
                                       data-edit-category="<?php echo e($category->id); ?>">Edit</a>
                                    <a href="#"
                                       class="btn btn-warning delete_category"
                                       data-delete-category="<?php echo e($category->id); ?>">Delete</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="accept" class="modal fade show" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Category
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('category.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name <span class="error">*</span></label>
                            <input type="text" name="name" class="form-control"
                                   id="name" required>
                        </div>

                        <div class="form-group">
                            <input type="submit"
                                   value="Submit"
                                   class="btn btn-info waves-effect waves-light"/>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect"
                            data-dismiss="modal">Close
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div id="update-modal" class="modal fade show" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Category
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" id="editCategoryForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="form-group">
                            <label for="name">Name <span class="error">*</span></label>
                            <input type="text" name="name" class="form-control"
                                   id="name" required>
                        </div>

                        <div class="form-group">
                            <input type="submit"
                                   value="Submit"
                                   class="btn btn-info waves-effect waves-light"/>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect"
                            data-dismiss="modal">Close
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('click', '.edit_category', function (ev) {
                ev.preventDefault();
                var val = $(this).data('edit-category');
                $.ajax({
                    url: 'category/' + val,
                    type: 'GET',
                    beforeSend: function () {
                    },
                    success: function (response) {
                        console.log(response.data);
                        $('#editCategoryForm')
                            .find('[name="name"]').val(response.data.name).end();

                        $("#editCategoryForm").attr("action", "category/" + response.data.id);
                        $("#update-modal").modal({backdrop: 'static', keyboard: true});
                    },
                    error: function (response) {
                        console.log(response);
                        alert('Operation failed');
                    }
                });
            });

            $(document).on('click', '.delete_category', function (ev) {
                ev.preventDefault();
                var val = $(this).data('delete-category');
                var r = confirm("Do you want to delete this user");
                if (r === true) {
                    $.ajax({
                        type: 'post',
                        url: "category/" + val,
                        data: {
                            '_method': 'DELETE',
                            "_token": "<?php echo e(csrf_token()); ?>",
                            'id': val
                        },
                        success: function (response) {
                            console.log(response.data);
                            if (response.data === 'ok') {
                                alert('Operation successful');
                                window.location.href = "<?php echo e(route('category.index')); ?>";
                            }
                        }
                    });
                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/category/index.blade.php ENDPATH**/ ?>