<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waves.min.js')); ?>"></script>
<!-- Required datatable js -->
<?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/includes/footer.blade.php ENDPATH**/ ?>