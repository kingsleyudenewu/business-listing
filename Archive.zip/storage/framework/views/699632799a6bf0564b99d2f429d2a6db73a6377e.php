<?php $__env->startSection('content'); ?>

    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title"><?php echo e($pageTitle); ?></h4>
                    </div>
                    <?php if(auth()->user()->id): ?>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <button class="btn btn-primary waves-effect waves-light"
                                        data-toggle="modal" data-target="#accept">Add Image
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div>Name: <?php echo e($businessListing->name); ?></div>
                    <div>Address <?php echo e($businessListing->address); ?></div>
                    <div>Phone <?php echo e($businessListing->phone); ?></div>
                    <div>Category
                        <?php $__currentLoopData = $businessListing->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($category->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div>Image
                        <?php $__currentLoopData = $businessListing->businessListingImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e(asset('storage/'.$image->image)); ?>" width="100px"
                                     height="auto"
                                     alt=""> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="accept" class="modal fade show" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" aria-modal="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Business Listing
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('business.listing.upload')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="business_listing_id" value="<?php echo e($businessListing->id); ?>">
                        <div class="form-group">
                            <label for="name">Logo</label>
                            <input type="file"
                                   name="image"
                                   class="form-control"
                            />
                        </div>

                        <div class="checkbox-row">
                            <label for="">Default</label>
                            <input type="checkbox" name="is_default" id="is_default" value="1">
                        </div>


                        <div class="form-group">
                            <input type="submit"
                                   value="Submit"
                                   class="btn btn-info waves-effect waves-light"/>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect"
                            data-dismiss="modal">Close
                    </button>
                </div>
            </div><!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kingsleyudenewu/PhpstormProjects/Initlisting/resources/views/business_listing/show.blade.php ENDPATH**/ ?>